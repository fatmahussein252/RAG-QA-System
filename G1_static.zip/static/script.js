// Define selectedModel globally within the script
let selectedModel = 'gemini'; // Default model

// Wait for the DOM to load
document.addEventListener('DOMContentLoaded', () => {
    console.log("DOM loaded, initializing elements"); // Debug log
    const queryInput = document.getElementById('queryInput');
    const searchButton = document.getElementById('searchButton');
    const searchMethod = document.getElementById('searchMethod');
    const gpt4oBtn = document.getElementById('gpt4oBtn');
    const geminiBtn = document.getElementById('geminiBtn');
    const searchResults = document.getElementById('searchResults');
    const ragResult = document.getElementById('ragResult');
    const llmOnlyResult = document.getElementById('llmOnlyResult');
    const loader = document.getElementById('loader');

    // Verify elements exist
    if (!queryInput || !searchButton || !searchMethod || !searchResults || !ragResult || !llmOnlyResult) {
        console.error("One or more DOM elements not found");
        return;
    }

    // Toggle model selection and show answers
    gpt4oBtn.addEventListener('click', () => {
        console.log("Switching to GPT-4o model");
        selectedModel = 'gpt4o';
        gpt4oBtn.classList.add('btn-primary');
        gpt4oBtn.classList.remove('btn-outline-primary');
        geminiBtn.classList.add('btn-outline-primary');
        geminiBtn.classList.remove('btn-primary');
        gpt4oBtn.style.opacity = '1';
        geminiBtn.style.opacity = '0.7';
        setTimeout(() => geminiBtn.style.opacity = '1', 300);
        fetchAndDisplayModelAnswers();
    });

    geminiBtn.addEventListener('click', () => {
        console.log("Switching to Gemini model");
        selectedModel = 'gemini';
        geminiBtn.classList.add('btn-primary');
        geminiBtn.classList.remove('btn-outline-primary');
        gpt4oBtn.classList.add('btn-outline-primary');
        gpt4oBtn.classList.remove('btn-primary');
        geminiBtn.style.opacity = '1';
        gpt4oBtn.style.opacity = '0.7';
        setTimeout(() => gpt4oBtn.style.opacity = '1', 300);
        fetchAndDisplayModelAnswers();
    });

    // Handle search
    searchButton.addEventListener('click', performSearch);
    queryInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            console.log("Enter key pressed, triggering search");
            performSearch();
        }
    });

    function performSearch() {
        const query = queryInput.value.trim();
        console.log("Search triggered with query:", query, "method:", searchMethod.value, "model:", selectedModel); // Debug log
        
        // Check if query or method is missing
        if (!query) {
            console.log("Empty query, showing alert");
            alert('يرجى إدخال سؤال!');
            return;
        }
        if (!searchMethod.value) {
            console.log("Search method not selected, showing alert");
            alert('يرجى اختيار طريقة بحث!');
            return;
        }

        loader.style.display = 'block';
        searchResults.innerHTML = '<p>جاري التحميل...</p>';
        ragResult.innerHTML = '<p>اختر نموذجًا لعرض الإجابة...</p>';
        llmOnlyResult.innerHTML = '<p>اختر نموذجًا لعرض الإجابة...</p>';

        // Use Colab's proxy URL
        const searchUrl = '/search';
        console.log("Sending fetch request to:", searchUrl); // Debug log
        fetch(searchUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ query, method: searchMethod.value, model: selectedModel })
        })
        .then(response => {
            console.log("Fetch response received:", response.status, response.statusText); // Debug log
            if (!response.ok) throw new Error('Network response was not ok: ' + response.statusText);
            return response.json();
        })
        .then(data => {
            console.log("Fetch data received:", data); // Debug log
            if (!data.paragraphs || !data.rag || !data.llm_only) {
                throw new Error("Invalid response data: missing 'paragraphs', 'rag', or 'llm_only'");
            }
            // Display 5 paragraphs
            searchResults.innerHTML = '';
            data.paragraphs.slice(0, 5).forEach((para, index) => {
                const card = document.createElement('div');
                card.className = 'paragraph-card';
                card.innerHTML = `<strong>الفقرة ${index + 1}:</strong> ${para}`;
                searchResults.appendChild(card);
            });
            loader.style.display = 'none';
        })
        .catch(error => {
            console.error('Fetch error:', error); // Debug log
            searchResults.innerHTML = `<p>خطأ: ${error.message}</p>`;
            loader.style.display = 'none';
        });
    }

    function fetchAndDisplayModelAnswers() {
        const query = queryInput.value.trim();
        if (!query || !searchMethod.value || !selectedModel) return;

        loader.style.display = 'block';
        ragResult.innerHTML = '<p>جاري التحميل...</p>';
        llmOnlyResult.innerHTML = '<p>جاري التحميل...</p>';

        const searchUrl = '/search';
        fetch(searchUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ query, method: searchMethod.value, model: selectedModel })
        })
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok: ' + response.statusText);
            return response.json();
        })
        .then(data => {
            if (!data.rag || !data.llm_only) {
                throw new Error("Invalid response data: missing 'rag' or 'llm_only'");
            }
            ragResult.innerHTML = `<p>${data.rag}</p><button class="btn btn-sm btn-primary mt-2" onclick="navigator.clipboard.writeText('${data.rag}'); alert('تم النسخ!')">نسخ</button>`;
            llmOnlyResult.innerHTML = `<p>${data.llm_only}</p><button class="btn btn-sm btn-primary mt-2" onclick="navigator.clipboard.writeText('${data.llm_only}'); alert('تم النسخ!')">نسخ</button>`;
            loader.style.display = 'none';
        })
        .catch(error => {
            console.error('Fetch error:', error);
            ragResult.innerHTML = `<p>خطأ: ${error.message}</p>`;
            llmOnlyResult.innerHTML = `<p>خطأ: ${error.message}</p>`;
            loader.style.display = 'none';
        });
    }

    // Auto-suggestions
    const suggestions = [
        'ما معنى الذكر والحذف؟',
        'ما مثال على حذف حرف في القرآن؟',
        'كيف يعمل البحث الدلالي؟'
    ];
    let suggestionList = null;

    queryInput.addEventListener('input', () => {
        const value = queryInput.value.toLowerCase();
        if (value && !suggestionList) {
            suggestionList = document.createElement('ul');
            suggestionList.className = 'list-group position-absolute w-100';
            suggestionList.style.zIndex = 1000;
            queryInput.parentElement.appendChild(suggestionList);
        }
        if (suggestionList) {
            suggestionList.innerHTML = '';
            if (value) {
                suggestions.filter(s => s.toLowerCase().includes(value))
                    .forEach(s => {
                        const li = document.createElement('li');
                        li.className = 'list-group-item list-group-item-action';
                        li.textContent = s;
                        li.addEventListener('click', () => {
                            queryInput.value = s;
                            suggestionList.remove();
                            suggestionList = null;
                        });
                        suggestionList.appendChild(li);
                    });
            } else if (suggestionList) {
                suggestionList.remove();
                suggestionList = null;
            }
        }
    });

    // Dark mode toggle
    const darkModeToggle = document.createElement('button');
    darkModeToggle.textContent = 'الوضع المظلم';
    darkModeToggle.className = 'btn btn-outline-primary position-absolute top-0 end-0 mt-2 me-2';
    document.body.appendChild(darkModeToggle);

    darkModeToggle.addEventListener('click', () => {
        document.body.classList.toggle('dark-mode');
        darkModeToggle.classList.toggle('btn-primary');
        darkModeToggle.classList.toggle('btn-outline-primary');
    });
});
